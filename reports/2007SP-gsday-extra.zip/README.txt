Girl Scout Day 2007
Creative Solutions



Included are all the activity instructional materials as well as the badge requirements we fulfilled for Creative Solutions and the evaluation sheet we used.

The "All GS Day Instructions" pdf contains all of the other PDFs merged into one, in case you find that to be a less cumbersome method of looking through everything.  The ledger spreadsheet for the Design a Town activity is also included.

-Liz Corson
5/28/07